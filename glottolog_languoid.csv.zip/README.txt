
Glottolog 4.4 data download
===========================

Data of Glottolog 4.4 is published under the following license:
https://creativecommons.org/licenses/by/4.0/

It should be cited as

Hammarström, Harald & Forkel, Robert & Haspelmath, Martin & Bank, Sebastian. 2021.
Glottolog 4.4.
Leipzig: Max Planck Institute for Evolutionary Anthropology.
https://doi.org/10.5281/zenodo.4061162
(Available online at http://glottolog.org, Accessed on 2021-05-14.)
